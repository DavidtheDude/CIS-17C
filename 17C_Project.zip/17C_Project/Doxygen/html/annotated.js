var annotated =
[
    [ "CharacterClasses", "class_character_classes.html", "class_character_classes" ]
];