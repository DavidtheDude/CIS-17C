/* 
 * File:   CharacterClasses.h
 * Author: David
 *
 * Created on November 10, 2014, 8:13 PM
 */

#ifndef CHARACTERCLASSES_H
#define	CHARACTERCLASSES_H
#include <string>


class CharacterClasses {
public:
    CharacterClasses();
    CharacterClasses(const CharacterClasses& orig);
    virtual ~CharacterClasses();
    void stuff(std::string ,int);
    void Assassin();
    void Warrior();
    void Mage();
    int rlevel(){return level;}
    std::string rClass(){return className;}
    int rbackstep(){return backstep;} //appear behind target and slash them
    int rassassinate(){return assassinate;} //perform an attack inflicting critical wounds
    int rhide(){return hide;} //increase chance to dodge and block
    int rsmoke(){return smoke;} //increase chance to dodge and block
    int robliterate(){ return obliterate;} //obliterate opponent
    int rfreeze(){return freeze;} //stun opponnent 
    int rempower(){return empower;} //empowers next ability
    int rdaze(){return daze;} //dazes opponent reducing block/dodge and increasing your block/dodge
    int rshout(){return shout;} //unleash a roar which will reduce enemies resistances
    int rblock(){return block;} //increase block chance reflecting a portion of the damage if the block is successful
    int rslash(){return slash;} //slash target
    int rsmash(){return smash;} //smash em
    float rcritChance(){return critChance;}
    float rcritResist(){return critResist;}
    float rmagResist(){return magResist;}
    float rblockChance(){return blockChance;}
    
private:
    //mage
    int obliterate; //obliterate opponent
    int freeze; //stun opponnent 
    int empower; //empowers next ability
    int daze; //dazes opponent reducing block/dodge and increasing your block/dodge
    //assassin
    int backstep; //appear behind target and slash them
    int assassinate; //perform an attack inflicting critical wounds
    int hide; //increase chance to dodge and block
    int smoke; //increase chance to dodge and block
    //warrior
    //abilities
    int shout; //unleash a roar which will reduce enemies resistances
    int block; //increase block chance reflecting a portion of the damage if the block is successful
    int slash; //slash target
    int smash;
    //all
    //defense
    float critChance;
    float critResist;
    float magResist;
    float blockChance;
    //level
    int level;
    //class
    std::string className;
    

};

#endif	/* CHARACTERCLASSES_H */

