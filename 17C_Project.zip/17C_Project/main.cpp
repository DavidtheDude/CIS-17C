/* 
 * File:   main.cpp
 * Author: David
 *
 * Created on November 3, 2014, 8:08 PM
 */

#include <cstdlib>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include <fstream>
#include <queue>
#include <ctime>
#include <stack>

#include "CharacterClasses.h"

using namespace std;


//start game
void start();
//character select
void charSelect(string, string &);
//game logic
void game(CharacterClasses &, CharacterClasses &);
//creating opponents
void createOpp();
//view high scores
void highScores();
//assassin class
void assassinUI(char &, int &, int &, bool, CharacterClasses &);
//mage class
void mageUI(char &, int &, int &, bool, CharacterClasses &);
//warrior class
void warriorUI(char &, int &, int &, bool, CharacterClasses &);
//match history
void matchHistory(bool);
//queue for a game
void queueGame(CharacterClasses &, CharacterClasses &);

int main(int argc, char** argv) {
    char input;
    do {
        cout << "Please select one." << endl;
        cout << "1. Start a New Game" << endl;
        cout << "2. End" << endl;
        cin >> input;
        if (input == '1')
            start();

    } while (input != '2');

    return 0;
}

void highScore() {
    //vector for high scores
    std::vector<int> b;
    fstream HS;
    long k;
    //reading in high scores
    HS.open("HS.txt");
    do {
        HS >> k;
        b.push_back(k);

    } while (HS.eof() != true);
    //set of high scores
    std::set<int> a(b.begin(), b.end());
    cout << "High Scores" << endl;
    cout << "By Set: ";
    for (std::set<int>::iterator it = a.begin(); it != a.end(); ++it) {
        cout << *it << " ";
    }
    cout << endl;
    //sorted vector using algorithm library for high scores
    cout << "By Algorithm: ";
    std::sort(b.begin(), b.end());
    for (std::vector<int>::iterator it = b.begin(); it != b.end(); ++it) {
        cout << *it << " ";
    }
    cout << endl;
    //showing high scores through stacks
    std::stack<int, std::vector<int> > c(b);
    cout << "By Stacks: ";
    for (int i = 0; i < c.size(); i++) {
        cout << c.top() << " ";
        c.pop();
    }
    cout << endl;

}

void game(CharacterClasses &player, CharacterClasses &opponent) {
    //starting hp
    int botHP = 200, myHP = 200;
    //input
    char k;
    //who's turn is it
    bool turn = true;
    //win or lose
    bool WL;
    cout << "Your opponent is a " << opponent.rClass() << endl;
    cout << "You are a " << player.rClass() << endl;
    cout << "Choose your move" << endl;
    do {
        //player's turn
        if (player.rClass() == "Assassin")
            assassinUI(k, myHP, botHP, turn, player);
        else if (player.rClass() == "Mage")
            mageUI(k, myHP, botHP, turn, player);
        else if (player.rClass() == "Warrior")
            warriorUI(k, myHP, botHP, turn, player);
        turn = false;
        //bot's turn
        if (botHP > 0 && myHP > 0) {
            if (opponent.rClass() == "Assassin")
                assassinUI(k, myHP, botHP, turn, opponent);
            else if (opponent.rClass() == "Mage")
                mageUI(k, myHP, botHP, turn, opponent);
            else if (opponent.rClass() == "Warrior")
                warriorUI(k, myHP, botHP, turn, opponent);
            turn = true;
        }
        //continue while someone's hp isn't 0 or below
    } while (botHP > 0 && myHP > 0);
    if (botHP <= 0) {
        //you win
        cout << "Congratulations you won!" << endl;
        WL = true;
    } else if (myHP <= 0) {
        //you lose
        cout << "Defeat!" << endl;
        WL = false;
    }
    //view match history
    matchHistory(WL);
    //view high score
    highScore();

}

void matchHistory(bool WL) {
    //open  up match history file
    fstream matchHistory;
    matchHistory.open("MH.txt");
    //write to it
    if (WL == true)
        matchHistory << "Win" << endl;
    else
        matchHistory << "Loss" << endl;
    //close it
    matchHistory.close();

}

void assassinUI(char &k, int &myHP, int &botHP, bool turn, CharacterClasses &person) {
    std::map<int, string> a;
    int bHP;
    a[1] = "Backstep";
    a[2] = "Assassinate";
    a[3] = "Hide";
    a[4] = "Smoke";
    for (std::map<int, string>::iterator it = a.begin(); it != a.end(); ++it) {
        cout << it->first << " " << it->second << endl;
    }
    if (turn == true) {
        cin >> k;
        cout << person.rbackstep() << endl;
        if (k == '1' && turn == true)
            botHP -= person.rbackstep();
        else if (k == '2' && turn == true)
            botHP -= person.rassassinate();
        else if (k == '3' && turn == true)
            botHP -= person.rhide();
        else if (k == '4' && turn == true)
            botHP -= person.rsmoke();
    }
    if (turn == false) {
        unsigned seed = time(0);
        srand(seed);
        k = rand() % 3 + 49;
        if (k == 49) {
            myHP -= person.rbackstep();
            cout << "Opponent used backstep" << endl;
        } else if (k == 50) {
            myHP -= person.rassassinate();
            cout << "Opponent used assassinate" << endl;
        } else if (k == 51) {
            myHP -= person.rhide();
            cout << "Opponent used hide" << endl;
        } else if (k == 52) {
            myHP -= person.rsmoke();
            cout << "Opponent used smoke" << endl;
        }
    }
    cout << "Current hp: " << myHP << endl;
    cout << "Opponent hp: " << botHP << endl;

}

void mageUI(char &k, int &myHP, int &botHP, bool turn, CharacterClasses &person) {
    std::map<int, string> a;
    a[1] = "Obliterate";
    a[2] = "Freeze";
    a[3] = "Empower";
    a[4] = "Daze";
    for (std::map<int, string>::iterator it = a.begin(); it != a.end(); ++it) {
        cout << it->first << " " << it->second << endl;
    }
    cin >> k;
    if (k == '1' && turn == true)
        botHP -= person.robliterate();
    else if (k == '2' && turn == true)
        botHP -= person.rfreeze();
    else if (k == '3' && turn == true)
        botHP -= person.rempower();
    else if (k == '4' && turn == true)
        botHP -= person.rdaze();
    if (turn == false) {
        unsigned seed = time(0);
        srand(seed);
        k = rand() % 3 + 49;
        if (k == 49) {
            myHP -= person.robliterate();
            cout << "Opponent used obliterate" << endl;
        } else if (k == 50) {
            myHP -= person.rfreeze();
            cout << "Opponent used freeze" << endl;
        } else if (k == 51) {
            myHP -= person.rempower();
            cout << "Opponent used empower" << endl;
        } else if (k == 52) {
            myHP -= person.rdaze();
            cout << "Opponent used daze" << endl;
        }
    }
    cout << "Current hp: " << myHP << endl;
    cout << "Opponent hp: " << botHP << endl;
}

void warriorUI(char &k, int &myHP, int &botHP, bool turn, CharacterClasses &person) {
    std::map<int, string> a;
    a[1] = "Shout";
    a[2] = "Block";
    a[3] = "Slash";
    a[4] = "Smash";
    for (std::map<int, string>::iterator it = a.begin(); it != a.end(); ++it) {
        cout << it->first << " " << it->second << endl;
    }
    cin >> k;
    if (k == '1' && turn == true)
        botHP -= person.rshout();
    else if (k == '2' && turn == true)
        botHP -= person.rblock();
    else if (k == '3' && turn == true)
        botHP -= person.rslash();
    else if (k == '4' && turn == true)
        botHP -= person.rsmash();
    if (turn == false) {
        unsigned seed = time(0);
        srand(seed);
        k = rand() % 3 + 49;
        if (k == 49) {
            myHP -= person.rshout();
            cout << "Opponent used shout" << endl;
        } else if (k == 50) {
            myHP -= person.rblock();
            cout << "Opponent used block" << endl;
        } else if (k == 51) {
            myHP -= person.rslash();
            cout << "Opponent used slash" << endl;
        } else if (k == 52) {
            myHP -= person.rsmash();
            cout << "Opponent used smash" << endl;
        }

    }
    cout << "Current hp: " << myHP << endl;
    cout << "Opponent hp: " << botHP << endl;
}

void start() {
    char input;
    string name;
    CharacterClasses player;
    CharacterClasses opponent;
    cout << "Choose your Class!" << endl;
    cout << "1. Warrior" << endl;
    cout << "2. Mage" << endl;
    cout << "3. Assassin" << endl;
    player.Warrior();
    player.Mage();
    player.Assassin();
    cin >> input;
    switch (input) {
        case '1':
        {
            charSelect("Warrior", name);
            player.stuff("Warrior", 1);
        }
            break;
        case '2':
        {
            charSelect("Mage", name);
            player.stuff("Mage", 1);

        }
            break;
        case '3':
        {
            charSelect("Assassin", name);
            player.stuff("Assassin", 1);
        }
    }
    cout << "You are now queued for matchmaking" << endl;
    queueGame(player, opponent);
    game(player, opponent);
}

void charSelect(string pClass, string &name) {
    cout << "Congratulations you chose a " << pClass << endl;
    cout << "Please enter a name for your " << pClass << endl;
    cin >> name;
}

void queueGame(CharacterClasses &player, CharacterClasses &opponent) {
    createOpp();
    fstream opponents;
    string l;
    int k;
    bool j;
    vector<string> a;
    opponents.open("opponents.txt");
    queue<int> queueList;
    priority_queue<int> priorityQueue;
    while (opponents.eof() != true) {
        opponents >> l; //class
        a.push_back(l);
        opponents >> k; //level
        opponents >> j; //p2w
        if (j == false) {
            queueList.push(k);
        } else
            priorityQueue.push(k);
    }
    int difference;
    int diff;
    bool found = false;
    for (int i = 0; i < priorityQueue.size(); i++) {
        difference = priorityQueue.top() - player.rlevel();
        diff = player.rlevel() - priorityQueue.top();
        if (diff < 5 || difference < 5) {
            cout << "A match has been found" << endl;
            found = true;
            i = priorityQueue.size();
        }
        priorityQueue.pop();
    }
    if (found == false) {
        for (int i = 0; i < queueList.size(); i++) {
            difference = queueList.front() - player.rlevel();
            diff = player.rlevel() - queueList.front();
            if (diff < 5 || difference < 5) {
                i = queueList.size();
                cout << "A match has been found" << endl;
                found = true;
            }
            queueList.pop();
        }
    }
    if (found == false) {
        cout << "No match was found" << endl;
        cout << "Trying again" << endl;
        queueGame(player, opponent);
    }
    opponent.stuff(l, k);
}

void createOpp() {
    unsigned seed = time(0);
    srand(seed);
    string rCharClass;
    vector<string> a;
    int inQueue = rand() % 1000;
    int rChar = rand() % 3 + 1;
    for (int i = 0; i < inQueue; i++) {
        if (rChar == 1)
            rCharClass = "Warrior";
        else if (rChar == 2)
            rCharClass = "Mage";
        else if (rChar == 3)
            rCharClass = "Assassin";
        a.push_back(rCharClass);
        rChar = rand() % 3 + 1;
    }

    fstream opponents;
    opponents.open("opponents.txt");
    for (int i = 0; i < inQueue; i++) {
        opponents << a.at(i) << endl;
        opponents << rand() % 10 + 1 << endl;
        opponents << (rand() / RAND_MAX) << endl;
    }
    opponents.close();
}


