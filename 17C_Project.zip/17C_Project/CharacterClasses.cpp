/* 
 * File:   CharacterClasses.cpp
 * Author: David
 * 
 * Created on November 10, 2014, 8:13 PM
 */

#include "CharacterClasses.h"

CharacterClasses::CharacterClasses() {
}

void CharacterClasses::stuff(std::string v, int k = 1) {
    level = k;
    if (v == "Assassin") {
        Assassin();
        className = v;
    } else if (v == "Warrior") {
        Warrior();
        className = v;
    } else if (v == "Mage") {
        Mage();
        className = v;
    }

}

CharacterClasses::CharacterClasses(const CharacterClasses& orig) {
}

CharacterClasses::~CharacterClasses() {
}

void CharacterClasses::Assassin() {
    //assassin
    /*
     * //base stats
        backstep = 100; //appear behind target and slash them
        assassinate = 200; //perform an attack inflicting critical wounds
        hide = 35; //increase chance to dodge and block
        smoke = 50; //increase chance to dodge and block
        //defense
        AcritChance = 50.0;
        AcritResist = 25.0;
        AmagResist = 25.0;
        Ablock = 20.0;
     */
    backstep = 100 + level; //appear behind target and slash them
    assassinate = 200 + level; //perform an attack inflicting critical wounds
    hide = 35 + level; //increase chance to dodge and block
    smoke = 50 + level; //increase chance to dodge and block
    //defense
    critChance = 50.0 + (float) level;
    critResist = 25.0 + (float) level;
    magResist = 25.0 + (float) level;
    block = 20.0 + (float) level;
}

void CharacterClasses::Warrior() {
    //warrior
    /*
     //base stats
    //abilities
    shout = 25; //unleash a roar which will reduce enemies resistances
    block = 50; //increase block chance reflecting a portion of the damage if the block is successful
    slash = 35; //slash target
    smash = 100;
    //defense
    WcritChance = 15.0; //crit chance
    WcritResist = 50.0; //crit resist
    WmagResist = 50.0; //magic resist
    Wblock = 30.0; //block chance passive
     */
    //abilities
    shout = 25 + level; //unleash a roar which will reduce enemies resistances
    block = 50 + level; //increase block chance reflecting a portion of the damage if the block is successful
    slash = 35 + level; //slash target
    smash = 100 + level; //smash em
    //defense
    critChance = 15.0 + (float) level;
    critResist = 50.0 + (float) level;
    magResist = 50.0 + (float) level;
    block = 30.0 + (float) level;
}

void CharacterClasses::Mage() {
    /*
     //base stats
    //abilities
    obliterate = 300; //obliterate opponent
    freeze = 100; //stun opponnent 
    empower = 100; //empowers next abilitys
    daze = 75; //dazes opponent reducing block/dodge and increasing your block/dodge
    //defense
    McritChance = 25.0;
    McritResist = 10.0;
    MmagResist = 60.0;
    Mblock = 10.0;
     
     */
    //mage
    obliterate = 300 + level; //obliterate opponent
    freeze = 100 + level; //stun opponnent 
    empower = 100 + level; //empowers next ability
    daze = 75 + level; //dazes opponent reducing block/dodge and increasing your block/dodge
    //defense
    critChance = 25 + (float) level;
    critResist = 10 + (float) level;
    magResist = 60 + (float) level;
    block = 10 + (float) level;
}

